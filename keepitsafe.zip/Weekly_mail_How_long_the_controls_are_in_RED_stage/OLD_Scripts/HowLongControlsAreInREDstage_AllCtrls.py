
#'\\\\ad.ing.net\\WPS\\NL\\P\\UD\\200028\\SI96PR\\Desktop\\stage_monitoring\\stage_monitoring_3_tentative.py'
#'\\\\ad.ing.net\\WPS\\NL\\P\\UD\\200028\\SI96PR\\Desktop\\stage_monitoring\\harish\\Stage_7_All_Control_sorted_4_Good.py'
#'\\\\ad.ing.net\\WPS\\NL\\P\\UD\\200028\\SI96PR\\Desktop\\stage_monitoring\\harish\\Stage_7_All_Control_sorted_3_Good_HowLong_Control_REDStage_2.py'

#------Multiple CSV to Multiple Xlsx then Multiple XLSX to filtered EXCEL------
import glob,os
import pandas as pd
import xlsxwriter
import xlrd
import csv
from glob import glob
from xlsxwriter.workbook import Workbook
#import os
from os import path
#import shutil
import time
from datetime import date
import datetime
import re

base_path_prev         = "\\\\ad.ing.net\\WPS\\NL\\P\\UD\\200028\\SI96PR\\Desktop\\stage_monitoring\\harish\\stg6to5\\Weekly_mail_How_long_the_controls_are_in_RED_stage\\"
base_path              = base_path_prev              + "input_CSV\\"
base_path_prev_1       = base_path_prev              + "Weekly_mail_final_sheets\\"  # this path is not added for auto create directory
excel_file_path        = base_path                   + "csvTOexceloutput\\"
excel_file_path_filter = excel_file_path             + "filtered_itrmp_dump\\"

csv_file_path1         = base_path                   + "*.csv"
excel_file_path_new    = excel_file_path_filter      + "*.xlsx"

sample_sheet_path      = base_path_prev_1            + "mul_excel_to_single_excel_stages.xlsx"
assets_area_path       = base_path_prev              + "Area_wise_Assets\\" + "Area_wise_codecheck.xlsx"

final_sheet_name       =                               "How_Long_In_RED_Stage_AllControls"

def existence_check(path_arg):
    
    val = os.path.exists(path_arg)
    
    if val == True:
        print("Directory is already Existing")
        Output_Dir = glob(path_arg + "/*.xlsx")
        print("Flushing old Output Files......")
        for file in Output_Dir:
            os.remove(file)
    else:
        print("Creating Directory!!!")
        try:  
            os.mkdir(str(path_arg))  
        except OSError as error:  
            print(error)

path_list = [base_path, excel_file_path, excel_file_path_filter]
for each_path in path_list:
    existence_check(each_path)



status = 0
no_of_files = 1

for csvfile in glob(csv_file_path1):
    #print("csv files name is : ", csvfile)
    name = os.path.basename(csvfile).split('.')[-2]
    #print("base name is : ", os.path.basename(csvfile))
# =============================================================================
#     excel_file_path = "\\".join(csv_file_path1.split("\\")[:-1]) + "\\" + "csvTOexceloutput" + "\\"
#     exist = path.exists(excel_file_path)
#         
#     if exist == True:
#         print("CSV-XLSX path exists ")
#         if no_of_files == 1:
#             for all_excel_files in glob(excel_file_path + '*.xlsx'):
#                 print("File exits  : Removed")
#                 os.remove(all_excel_files)
#     else:
#         try:  
#             os.mkdir(excel_file_path) 
#             print("Creating Directory!!!")
#         except OSError as error:  
#             print(error)
# =============================================================================
            
    if os.path.isfile(excel_file_path + str(name) + '.xlsx'):
        os.remove(excel_file_path + str(name) + '.xlsx')
    workbook = Workbook(excel_file_path + str(name) + '.xlsx', {'strings_to_numbers': True,'constant_memory': True})
    worksheet = workbook.add_worksheet()
    with open(csvfile, 'r') as f:
        r = csv.reader(f)
        for row_index, row in enumerate(r):
            for col_index, data in enumerate(row):
                worksheet.write(row_index, col_index, data)
        workbook.close()
    print("-------------------------------------------")
    print("File {0} : .CSV to .XLSX Conversion Successful".format(no_of_files))
    no_of_files = no_of_files + 1
    status = 1
      
if status == 1:
    first_file = 1
    excel_file_path_with_file = "\\".join(excel_file_path.split("\\")[:-1]) + "\\" + "*.xlsx" 
    print("Excel file path is : ", excel_file_path_with_file)
    for excelfile in glob(excel_file_path_with_file):
        name = os.path.basename(excelfile).split('.')[-2]
        #excel_file_path = "\\".join(excel_file_path_with_file.split("\\")[:-1]) + "\\"
        excel_file_name_full_path = excel_file_path + str(name) + '.xlsx'
        if os.path.isfile(excel_file_name_full_path):
            print("Excel file - {0} exists---PROCEED with filtering".format(first_file))
        
            dfs = pd.read_excel(excel_file_name_full_path)
            #dfs.dropna(inplace=True)
        
# =============================================================================
#             status_stage5 = dfs.u_lifecycle.eq("5. NOT OK 1st LoD (incl. evidence)")
#             status_stage6 = dfs.u_lifecycle.eq("6. Ready for 1st LoD review (incl. evidence)")
#             status_stage8 = dfs.u_lifecycle.eq("8. OK by 1stLoD (incl. evidence)")
#             status_merge = status_stage5 | status_stage6 | status_stage8
#             oper_status =  ~dfs['u_cmdb_ci.operational_status'].eq('Non-Operational')
#             not_EAI = ~dfs.u_region.eq('EA&I')
#             dfs_action1 = dfs[not_EAI & oper_status & status_merge]
#             dfs_action2 = dfs[oper_status & dfs['u_cmdb_ci.name'].eq("iStore2") & dfs.u_region.eq('EA&I') & status_merge]
#             dfs_merge = [dfs_action1, dfs_action2]
#             dfs_action = pd.concat(dfs_merge)
# 
# =============================================================================

# =============================================================================
#             status_stage1 = dfs.u_lifecycle.eq("1. No data")
#             status_stage2 = dfs.u_lifecycle.eq("2. Tell Me Not OK (no evidence)")
#             status_stage3 = dfs.u_lifecycle.eq("YET TO GET")
#             status_stage4 = dfs.u_lifecycle.eq("4. TELL ME – OK")
#             status_stage5 = dfs.u_lifecycle.eq("5. NOT OK 1st LoD (incl. evidence)")
#             status_stage_merge = status_stage1 | status_stage2 | status_stage3 | status_stage4 | status_stage5
#             oper_status =  ~dfs['u_cmdb_ci.operational_status'].eq('Non-Operational')
#             not_EAI = ~dfs.u_region.eq('EA&I')
#             dfs_action1 = dfs[not_EAI & status_stage_merge & oper_status]
#             dfs_action2 = dfs[dfs['u_cmdb_ci.name'].eq("iStore2") & dfs.u_region.eq('EA&I') & status_stage_merge & oper_status]
#             dfs_merge = [dfs_action1, dfs_action2]
#             dfs_action = pd.concat(dfs_merge)
# =============================================================================

            oper_status =  ~dfs['u_cmdb_ci.operational_status'].eq('Non-Operational')
            not_EAI = ~dfs.u_region.eq('EA&I')
            dfs_action1 = dfs[oper_status & not_EAI]
            dfs_action2 = dfs[dfs['u_cmdb_ci.name'].eq("iStore2") & dfs.u_region.eq('EA&I')]
            dfs_merge = [dfs_action1, dfs_action2]
            dfs_action = pd.concat(dfs_merge)
            
# =============================================================================
#             excel_file_path_filter = excel_file_path + "filtered_itrmp_dump\\"
#             exist = path.exists(excel_file_path_filter)
#             
#             if exist == True:
#                 print("filtered Directory path exists ")
#                 if first_file == 1:
#                     for all_excel_files in glob(excel_file_path_filter + '*.xlsx'):
#                         print("File exits  : Removed")
#                         os.remove(all_excel_files)
#             else:
#                 try:  
#                     os.mkdir(excel_file_path_filter) 
#                     print("Creating Directory!!!")
#                 except OSError as error:  
#                     print(error)
# =============================================================================
            
            writer = pd.ExcelWriter(excel_file_path_filter + str(name) + '_filtered' + '.xlsx', engine='xlsxwriter')
            workbook = writer.book
            sheet_name = 'ResultData_New'
            dfs_action.to_excel(writer, sheet_name = sheet_name)
            worksheet = writer.sheets[sheet_name]
            border_fmt = workbook.add_format({'bottom': 2, 'top': 2, 'left': 2, 'right': 2})
            format1 = workbook.add_format({'font_color': 'red', 'font_name': 'Times New Roman'})
            worksheet.set_column('A:L', 20, format1)
            worksheet.conditional_format(xlsxwriter.utility.xl_range(0, 0, len(dfs_action), len(dfs_action.columns)),
                                         {'type': 'no_errors', 'format': border_fmt})
            writer.save()
            writer.close()
            first_file = first_file + 1
        else:
            print("Excel file - {0} doesn't exists---".format(first_file))

print("\n SUCCESS : Multiple CSV to Multiple Xlsx then Multiple XLSX to filtered EXCEL")

time.sleep(5)

#--------------Multiple Xlsx to Single Xlsx with - fetch the stages------------


#excel_file_path = excel_file_path_new
#resultSheet = resultSheet_1
resultSheet = xlsxwriter.Workbook(sample_sheet_path)
#resultSheet = xlsxwriter.Workbook(r'\\ad.ing.net\WPS\NL\P\UD\200028\SI96PR\Desktop\stage_monitoring\harish\output\sample_new.xlsx')

first_file = 1
row, col_asset, col_control, col_stage_date = 1, 0, 1, 2
row_header, col_header = 0, 2

excel_file_path_with_file = "\\".join(excel_file_path_new.split("\\")[:-1]) + "\\" + "*.xlsx" 

print("Excel file path is : ", excel_file_path_with_file)
#print("Excel file path is--- : ", excel_file_path_new)

new_list = []
for excelfile in glob(excel_file_path_with_file):
    name = os.path.basename(excelfile).split('.')[-2]
    #print("Excel name is : ", name)
    excel_file_path = "\\".join(excel_file_path_with_file.split("\\")[:-1]) + "\\"
    excel_file_name_full_path = excel_file_path + str(name) + '.xlsx'
    if os.path.isfile(excel_file_name_full_path):
        
        dfs = pd.read_excel(excel_file_name_full_path)
        #dfs.dropna(inplace=True)

        assets = dfs['u_cmdb_ci.name']
        controls = dfs['u_ocd_question.u_question_reference']
        stage = dfs['u_lifecycle']

        
        assets_list = assets.tolist()
        controls_list = controls.tolist()
        stage_list = stage.tolist()  
        asset_control_stage = [a_c_s for a_c_s in zip(assets_list, controls_list, stage_list)]
        
        asset_control_stage = sorted(asset_control_stage, key = lambda x: (x[0], x[1]))

        if first_file == 1:
            asset_control_name_list_1st_file = asset_control_stage
            print("File number {} - Data length : {}".format(first_file, len(asset_control_name_list_1st_file)) )

            dataSheet = resultSheet.add_worksheet()
            dataSheet.set_column(0,1,30)

            dataSheet.write('A1','Assets')
            dataSheet.write('B1','Controls')
        else:
            asset_control_name_list_OtherThanFirstFIle = asset_control_stage
            print("File number {} - Data length : {}".format(first_file, len(asset_control_name_list_OtherThanFirstFIle)) )
            
        asset_control_name_list_1st_file.extend(new_list)
        asset_control_name_list_1st_file_Only_a_c = [i[0:2] for i in asset_control_name_list_1st_file]
            
        file_date = re.split('(\d{4}-\d{2}-\d{2})', name)[1]
        print("file date is : ", file_date)
        dataSheet.write(row_header, col_header, str(file_date))
        
        
        
        
        if first_file == 1:
            dump_file_start_date = file_date
            for data in asset_control_stage:
                asst, contr, stg = data
                dataSheet.write(row, col_asset, asst)
                dataSheet.write(row, col_control, contr)
                dataSheet.write(row, col_stage_date, int(stg[0])) # Extract and write stage to the excel
                #dataSheet.write(row, col_stage_date, contr)  # printing contrl - just for checking purpose
                row = row + 1
        else:
            for a_c_s_static in asset_control_name_list_1st_file:
                for a_c_s_dynamic in asset_control_name_list_OtherThanFirstFIle:
                    if a_c_s_static[0:2] == a_c_s_dynamic[0:2]:
                        #print(j[0:2])  # (Asset, Control)
                        dataSheet.write(row, col_stage_date, int(a_c_s_dynamic[2][0])) # Extract and write stage to the excel
                        #dataSheet.write(row, col_stage_date, a_c_s_dynamic[1])  # printing contrl (a_c_s_dynamic[1]) - just for checking purpose
                row = row + 1
            
            print("No of rows is : ", row)
            new_list.clear()
            new_list = [a_c_s_dynamic for a_c_s_dynamic in asset_control_name_list_OtherThanFirstFIle if a_c_s_dynamic[0:2] not in asset_control_name_list_1st_file_Only_a_c]
            for a_c_s_dynamic_newlist in new_list:
                dataSheet.write(row, col_asset, a_c_s_dynamic_newlist[0])
                dataSheet.write(row, col_control, a_c_s_dynamic_newlist[1])
                #dataSheet.write(row, col_stage_date, a_c_s_dynamic_newlist[1]) # # printing contrl 
                dataSheet.write(row, col_stage_date, int(a_c_s_dynamic_newlist[2][0]))
                row = row + 1
                        
    print("new_list Length", len(new_list))
    first_file = first_file + 1
    row = 1
    col_stage_date = col_stage_date + 1
    col_header = col_header + 1

dump_file_end_date = file_date
resultSheet.close()
print("SUCCESS")
print("\n SUCCESS : Multiple Xlsx to Single Xlsx with - fetch the stages")

print("dump_file_start_date : ", dump_file_start_date)
print("dump_file_end_date : ", dump_file_end_date)

time.sleep(5)

#---------------------How Long Ctrl In Red Stage-------------------------

#excel_file_name_full_path = sample_sheet_path

first_file = 1
row, col_asset, col_control, col_stage_date = 1, 0, 1, 2
row_header, col_header = 0, 2

def last_index(items_list, value):
    return len(items_list) - items_list[::-1].index(value) - 1   # It will give the last index of the given number

if os.path.isfile(sample_sheet_path):
      
    wb = xlrd.open_workbook(sample_sheet_path) 
    sheet = wb.sheet_by_index(0)
    sheet.cell_value(0, 0) 
    #print("Number of rows are : ", sheet.nrows)
    
    new_list = [sheet.row_values(i) for i in range((sheet.nrows))][1:] # 1: at the end to remove the 1st row
    #print("Len of new list : Except 1st row is : ", len(new_list))
    print("------------------------")
    last_index_green_stage = []
    list_of_asset_control_RedStgDays =[]
    asset_control_RedStgDays = []
    for rows in new_list:
        for i in rows:
            if i == 8 or i == 9 or i == 6:
                last_index_green_stage.append(last_index(rows, i))  # It will get the last index of the given number
        if last_index_green_stage:
            red_stg_no_of_days = len(rows) - last_index_green_stage[-1] - 1
        else:
            red_stg_no_of_days = len(rows) - 2 # first 2 columns contains asset&control, so doing minus 2
        if red_stg_no_of_days > 1:
            if red_stg_no_of_days == len(rows) - 2 :
                asset_control_RedStgDays = [rows[0], rows[1], ">= " + str(red_stg_no_of_days) + " Days"]
                list_of_asset_control_RedStgDays.append(asset_control_RedStgDays)
            else:
                asset_control_RedStgDays = [rows[0], rows[1], str(red_stg_no_of_days) + " Days"]
                list_of_asset_control_RedStgDays.append(asset_control_RedStgDays)
        elif red_stg_no_of_days == 1:
            asset_control_RedStgDays = [rows[0], rows[1], str(red_stg_no_of_days) + " Day"]
            list_of_asset_control_RedStgDays.append(asset_control_RedStgDays)
        else:
            pass

        last_index_green_stage = []
        asset_control_RedStgDays = []
        
    list_of_asset_control_RedStgDays = sorted(list_of_asset_control_RedStgDays, key = lambda x: (x[1]))

#------------------------------------------------------------------------------
        
#--------------------------- LIST : asset_control_stageLastCol_new ------which stage------------------------------------
xl = pd.ExcelFile(sample_sheet_path)
ncols = xl.book.sheets()[0].ncols
df = xl.parse(0, usecols=[0, 1, ncols-1])  # to get only the 1st, 2nd and last column

Assets   = df.iloc[:, 0].tolist()    # to get only the 1st column
Controls = df.iloc[:, 1].tolist()  # to get only the 2nd column
stage    = df.iloc[:, 2].tolist()     # to get only the last column

asset_control_stageLastCol = [list(a_c_s) for a_c_s in zip(Assets, Controls, stage)]

#print(asset_control_stageLastCol)
#asset_control_stageLastCol_new = [i for i in asset_control_stageLastCol if i[2] == 0 or i[2] == 1 or i[2] == 2 or i[2] == 4 or i[2] == 5]
asset_control_stageLastCol_new = [i for i in asset_control_stageLastCol if i[2] == 1 or i[2] == 2 or i[2] == 4 or i[2] == 5]

#--------------LIST of DICT---AREA wise ASSETS------------

def get_assets_area():
    areaAssetDoc = xlrd.open_workbook(assets_area_path)
    mySheet = areaAssetDoc.sheet_by_index(0)   # Reading from the 1st sheet
    area = []
    areaAssetList = []
    for x in range(mySheet.nrows):
        if x > 0:
            area.append(mySheet.cell_value(x,2))
            areaAssetList.append(mySheet.cell_value(x,0)+','+mySheet.cell_value(x,2))  # Asset name, area will be stored here
    
    area_Entity = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'Entity']
    area_OneConnect = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'OneConnect']
    area_OneEngagement = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'OneEngagement']
    area_OneExperience = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'OneExperience']
    area_OneGate = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'OneGate']
    area_OnePam = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'OnePam']
    area_OnePlatform = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'OnePlatform']
    area_iStore2 = [x.split(',')[0] for x in areaAssetList if x.split(',')[1] == 'iStore2']
    
    all_area_asset_list = [{"OneConnect" : area_OneConnect}, {"OneEngagement" : area_OneEngagement},
                       {"OneExperience" : area_OneExperience}, {"OneGate" : area_OneGate}, {"OnePam" : area_OnePam}, 
                       {"OnePlatform" : area_OnePlatform}, {"Entity" : area_Entity}, {"iStore2" : area_iStore2}]
    
    return all_area_asset_list



#-----------------LIST------Assets, Controls, In Which Stage------------------- 

print("---Assets, Controls, In Which Stage---")
#print(asset_control_stageLastCol_new)
print("asset_control_stageLastCol_new : ", len(asset_control_stageLastCol_new))
print("\n")

#------------LIST---------Assets, Controls, How Long In RED Stage--------------

print("-Assets, Controls, How Long In RED Stage-")
list_of_asset_control_howLongCtrlInRedStage = list_of_asset_control_RedStgDays
#print(list_of_asset_control_howLongCtrlInRedStage)
print("list_of_asset_control_howLongCtrlInRedStage : ", len(list_of_asset_control_howLongCtrlInRedStage))
print("\n")
# =============================================================================
#-----------------------------------------------------------------------------

#resultSheet = xlsxwriter.Workbook(r'\\ad.ing.net\WPS\NL\P\UD\200028\SI96PR\Desktop\stage_monitoring\harish\output\How_Long_In_RED_Stage.xlsx')
#resultSheet = xlsxwriter.Workbook(r'\\ad.ing.net\WPS\NL\P\UD\200028\SI96PR\Desktop\stage_monitoring\harish\output\How_Long_In_RED_Stage_AllControls_Till_%s.xlsx'%dump_file_end_date)
resultSheet          = xlsxwriter.Workbook(base_path_prev_1 + final_sheet_name +"_%s.xlsx"%dump_file_end_date)

all_assets_area = get_assets_area()  # calling method
for area_assets in all_assets_area:    # It will go area wise, [area : [assets]]
    for area, assets in area_assets.items():
        area_name = area
        asset_names = assets  ## its a list
        #print(asset_names)
        #print(area_name)
    
    #print(list_of_asset_control_howLongCtrlInRedStage)
    
    final_list = []
    for asset_list_data in asset_names:
        for stage_list in asset_control_stageLastCol_new:
            if asset_list_data ==  stage_list[0]:
                for howLongRed_list_data in list_of_asset_control_howLongCtrlInRedStage:
                    if stage_list[0:2] == howLongRed_list_data[0:2]:
                        stage_list.append(howLongRed_list_data[-1])
                        final_list.append(stage_list)
# =============================================================================
#     final_list = []
#     for asset_list_data in asset_names:
#         for howLongRed_list_data in list_of_asset_control_howLongCtrlInRedStage:
#             if asset_list_data ==  howLongRed_list_data[0]:
#                 for stage_list in asset_control_stageLastCol_new:
#                     if howLongRed_list_data[0:2] == stage_list[0:2]:
#                         howLongRed_list_data.append(stage_list[-1])
#                         final_list.append(howLongRed_list_data)
# =============================================================================

    #print(final_list)
    #final_list = sorted(final_list, key = lambda x: (x[1]))
    final_list = sorted(final_list, key = lambda x: (x[0]))
            

    dataSheet = resultSheet.add_worksheet(area_name)
    dataSheet.set_column(0,1,30)
    dataSheet.write('A1','AREA     : ')
    dataSheet.write('B1',area_name)
    dataSheet.write('A2','Assets')
    dataSheet.write('B2','Controls')
    dataSheet.write('C2','Current Stage')
    dataSheet.write('D2','   RED Stage : Duration')
    
    dataSheet.set_column('A:A', 30)
    dataSheet.set_column('B:B', 25)
    dataSheet.set_column('C:C', 15)
    dataSheet.set_column('D:D', 25)
    dataSheet.set_column('F:F', 28)
    dataSheet.set_column('H:H', 20)
    dataSheet.set_column('I:I', 15)
    
    dataSheet.autofilter('A2:D2')  # to apply auto filter
    
    cell_format = resultSheet.add_format()
    cell_format.set_bold()
    cell_format.set_font_color('black')
    #cell_format.set_align('center')
    
    cell_format1 = resultSheet.add_format()
    cell_format1.set_bold()
    cell_format1.set_font_color('red')
    cell_format1.set_align('center')
        
    info = "Controls are in RED stage are :>"
    dataSheet.write('F2',info)
    dataSheet.write('G2',len(final_list), cell_format1)
    
    #count_0_stg, count_1_stg, count_2_stg, count_4_stg, count_5_stg = 0,0,0,0,0
    count_1_stg, count_2_stg, count_4_stg, count_5_stg = 0,0,0,0
    for i in final_list:
# =============================================================================
#         if i[2] == 0:
#             count_0_stg = count_0_stg + 1
# =============================================================================
            
        if i[2] == 1:
            count_1_stg = count_1_stg + 1
            
        elif i[2] == 2:
            count_2_stg = count_2_stg + 1
            
        elif i[2] == 4:
            count_4_stg = count_4_stg + 1
            
        elif i[2] == 5:
            count_5_stg = count_5_stg + 1

    #stg_0 = "Controls are in 0th stage are :>"
    stg_1 = "Controls are in 1st stage are :>"
    stg_2 = "Controls are in 2nd stage are :>"
    stg_4 = "Controls are in 4th stage are :>"
    stg_5 = "Controls are in 5th stage are :>"
    
# =============================================================================
#     dataSheet.write('F4',stg_0)
#     dataSheet.write('G4',count_0_stg, cell_format1)
# =============================================================================
    
    dataSheet.write('F4',stg_1)
    dataSheet.write('G4',count_1_stg, cell_format1)
    
    dataSheet.write('F6',stg_2)
    dataSheet.write('G6',count_2_stg, cell_format1)
    
    dataSheet.write('F8',stg_4)
    dataSheet.write('G8',count_4_stg, cell_format1)
    
    dataSheet.write('F10',stg_5)
    dataSheet.write('G10',count_5_stg, cell_format1)
    
    dataSheet.write('H2', "Reading Dump From :> ")
    dataSheet.write('H3', "Reading Dump To   :> ")
    
    dataSheet.write('I2', dump_file_start_date, cell_format1)
    dataSheet.write('I3', dump_file_end_date, cell_format1)
    
    #dataSheet.filter_column('A', 'x > 2000')  # to apply filter for specific conditions
    
    format1 = resultSheet.add_format({'bg_color': 'pink'})  # Pink Background
    format2 = resultSheet.add_format({'bg_color': 'red'})  # Red Background
    format3 = resultSheet.add_format({'bg_color': 'yellow'})  # Yellow Background
    format4 = resultSheet.add_format({'bg_color': 'green'})  # Green Background
    
    dataSheet.conditional_format('A1', {'type': 'cell', 'criteria': '>=', 'value':0, 'format': format1})
    dataSheet.conditional_format('B1', {'type': 'cell', 'criteria': '>=', 'value':0, 'format': format3})
    dataSheet.conditional_format('A2:D2', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format2})
    dataSheet.conditional_format('F2', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format1})
    dataSheet.conditional_format('F4', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format3})
    dataSheet.conditional_format('F6', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format3})
    dataSheet.conditional_format('F8', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format3})
    dataSheet.conditional_format('F10', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format3})
    #dataSheet.conditional_format('F12', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format3})
    dataSheet.conditional_format('H2', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format3})
    dataSheet.conditional_format('H3', {'type': 'cell', 'criteria': '>=', 'value': 0, 'format': format3})
    
   
    row, col_asset, col_control, col_stage, col_red_how_long = 2, 0, 1, 2, 3
    row_header, col_header = 0, 2
    
    for data in final_list:
        asst, contr, stg, how_long = data
        
        dataSheet.write(row, col_asset, asst, cell_format)
        dataSheet.write(row, col_control, contr, cell_format)
        dataSheet.write(row, col_stage, stg, cell_format1)
        dataSheet.write(row, col_red_how_long, how_long, cell_format1)
        row = row + 1

resultSheet.close()
print("SUCCESS")




